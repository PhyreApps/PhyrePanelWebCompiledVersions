<?php

namespace Modules\Docker\Filament\Clusters;

use Filament\Clusters\Cluster;

class DockerCluster extends Cluster
{
    protected static ?string $navigationIcon = 'docker-logo';

    protected static ?string $navigationGroup = 'Docker';

}
