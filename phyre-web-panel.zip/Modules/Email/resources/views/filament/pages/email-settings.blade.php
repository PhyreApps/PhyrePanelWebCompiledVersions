<x-filament-panels::page>

    <div>
        Email settings
    </div>

</x-filament-panels::page>
