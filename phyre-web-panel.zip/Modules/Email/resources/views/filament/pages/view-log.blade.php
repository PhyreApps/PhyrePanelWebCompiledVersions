<x-filament-panels::page>

    <div>
        <h1>Service Log</h1>
        <pre>{{ $logContents }}</pre>
    </div>
</x-filament-panels::page>
