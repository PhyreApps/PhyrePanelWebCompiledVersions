<?php

return [
    'name' => 'Microweber',
    'sharedPaths' => [
        'app' => '/usr/share/microweber/latest',
        'modules' => '/usr/share/microweber/latest/Modules',
        'templates' => '/usr/share/microweber/latest/Templates',
    ],

];
