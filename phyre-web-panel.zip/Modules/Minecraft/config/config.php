<?php

return [
    'name' => 'Minecraft',
];
