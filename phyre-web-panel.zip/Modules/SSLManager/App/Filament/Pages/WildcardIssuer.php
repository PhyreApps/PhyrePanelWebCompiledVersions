<?php

namespace Modules\SSLManager\App\Filament\Pages;

use Filament\Pages\Page;

class WildcardIssuer extends Page
{
    protected static string $view = 'sslmanager::filament.pages.wildcard-issuer';

    protected static ?string $navigationGroup = 'SSL Manager';


}
