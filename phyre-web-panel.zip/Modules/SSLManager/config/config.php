<?php

return [
    'name' => 'SSLManager',
];
