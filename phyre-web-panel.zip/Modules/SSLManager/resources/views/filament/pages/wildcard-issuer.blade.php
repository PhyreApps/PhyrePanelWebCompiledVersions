<x-filament-panels::page>

<div>
{{ $this->form }}
</div>

</x-filament-panels::page>