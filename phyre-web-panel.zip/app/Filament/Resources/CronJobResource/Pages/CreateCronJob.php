<?php

namespace App\Filament\Resources\CronJobResource\Pages;

use App\Filament\Resources\CronJobResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCronJob extends CreateRecord
{
    protected static string $resource = CronJobResource::class;
}
