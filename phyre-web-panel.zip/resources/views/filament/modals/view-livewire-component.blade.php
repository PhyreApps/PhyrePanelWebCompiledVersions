<div>

    @livewire($component, $componentProps)

</div>
